from django.db import models
from sales.models import Order

class Invoice(models.Model):
    order = models.OneToOneField(Order, on_delete=models.CASCADE, primary_key=True) # One invoice per order
    invoice_number = models.CharField(max_length=50, unique=True)
    issue_date = models.DateField(auto_now_add=True)
    due_date = models.DateField()
    status_choices = [
        ('PENDING', 'Pending'),
        ('PAID', 'Paid'),
        ('CANCELLED', 'Cancelled'),
    ]
    status = models.CharField(
        max_length=10,
        choices=status_choices,
        default='PENDING',
    )

    def __str__(self):
        return f"Invoice {self.invoice_number} ({self.status})"